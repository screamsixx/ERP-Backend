import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
require('dotenv').config();

interface User {
  id: number;
  email: string;
  password?: string; // Opcional para no incluirlo en el JWT
  nombre: string;
  apellidoPaterno?: string;
  apellidoMaterno: string;
  fechaNacimiento?: string; // Opcional para no incluirlo en el JWT
  esAdmin: boolean;
}

interface JwtPayload extends Pick<User, 'id' | 'email' | 'nombre' | 'apellidoPaterno' | 'apellidoMaterno' | 'esAdmin'> { }
interface CustomRequest extends Request { //clase personalizada
  user?: JwtPayload;
}

export class AuthMiddleware {
  private secret: string;

  constructor() {
    this.secret = process.env.JWT_SECRET || 'your_default_secret';
  }

  public async verifyToken(req: CustomRequest, res: Response, next: NextFunction) {
    const authHeader = req.headers.authorization;
    const token = authHeader && authHeader.split(' ')[1];
    if (!token) {
      return res.status(401).json({ message: 'No autorizado' });
    }

    try {
      const decoded = jwt.verify(token, this.secret) as JwtPayload;
      req.user = decoded;
      next();
    } catch (error) {
      console.error(error);
      return res.status(403).json({ message: 'Prohibido' });
    }
  }
}

